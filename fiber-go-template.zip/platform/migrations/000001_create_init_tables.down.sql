-- Delete tables
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS users;