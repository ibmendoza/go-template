# ./docs

**Folder with API Documentation**. This directory contains config files for auto-generated API Docs by Swagger.
