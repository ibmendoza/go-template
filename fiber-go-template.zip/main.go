package main

import (
	"os"

	"github.com/rs/zerolog/log" //include in every package where needed

	"github.com/create-go-app/fiber-go-template/pkg/configs"
	"github.com/create-go-app/fiber-go-template/pkg/middleware"
	"github.com/create-go-app/fiber-go-template/pkg/routes"
	"github.com/create-go-app/fiber-go-template/pkg/utils"

	"github.com/gofiber/fiber/v2"

	_ "github.com/create-go-app/fiber-go-template/docs" // load API Docs files (Swagger)

	_ "github.com/joho/godotenv/autoload" // load .env file automatically
)

// @title API
// @version 1.0
// @description This is an auto-generated API Docs.
// @termsOfService http://swagger.io/terms/
// @contact.name API Support
// @contact.email your@mail.com
// @license.name Apache 2.0
// @license.url http://www.apache.org/licenses/LICENSE-2.0.html
// @BasePath /api
// @securityDefinitions.apikey ApiKeyAuth
// @in header
// @name Authorization
func main() {
	/*
		log := zerolog.New(os.Stdout).With().
			Timestamp().
			Logger()
	*/

	// Define Fiber config.
	config := configs.FiberConfig()

	// Define a new Fiber app with config.
	app := fiber.New(config)

	// Below is just for tutorial reference

	// This route path will match requests to the root route, "/":
	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendString("root")
	})

	// This route path will match requests to "/about":
	app.Get("/about", func(c *fiber.Ctx) error {
		log.Info().
			Str("zerolog", "Demo https://github.com/rs/zerolog/log which provides a global logger for zerolog").
			Str("Scale", "833 cents").
			Float64("Interval", 833.09).
			Msg("Fibonacci is everywhere")

		return c.SendString("about")
	})

	//end reference

	// Middlewares.
	middleware.FiberMiddleware(app) // Register Fiber's middleware for app.

	// Routes.
	routes.SwaggerRoute(app)  // Register a route for API Docs (Swagger).
	routes.PublicRoutes(app)  // Register a public routes for app.
	routes.PrivateRoutes(app) // Register a private routes for app.
	routes.NotFoundRoute(app) // Register route for 404 Error.

	// Start server (with or without graceful shutdown).
	if os.Getenv("STAGE_STATUS") == "dev" {
		utils.StartServer(app)
	} else {
		utils.StartServerWithGracefulShutdown(app)
	}

}
