// can have multiple handlers on multiple files depending on your business logic
package main

import (
	"errors"
	"log"

	"github.com/nsqio/go-nsq"
)

// HandleMessage is the only requirement needed to fulfill the
// nsq.Handler interface. This where you'll write your message
// handling logic.
func (h *MessageHandler) HandleMessage(m *nsq.Message) error {
	if len(m.Body) == 0 {
		// returning an error results in the message being re-enqueued
		// a REQ is sent to nsqd
		return errors.New("body is blank re-enqueue message")
	}

	//this is just a sample of biz logic
	log.Println(string(m.Body))

	/*
		put your business logic here
	*/

	// Returning nil signals to the consumer that the message has
	// been handled with success. A FIN is sent to nsqd
	return nil
}
